/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */
package com.salesforce.android.mobile.interfaces.navigation

import com.salesforce.android.mobile.interfaces.navigation.destination.App
import com.salesforce.android.mobile.interfaces.navigation.destination.Destination

interface Navigation {
    /**
     * Goes to a destination
     *
     * @param destination The destination
     */
    fun goto(destination: Destination)

    /**
     * Goes to a destination
     *
     * @param destination The destination
     * @param replace true if the host app needs to replace the existing page with this,
     *                false otherwise
     */
    fun goto(
        destination: Destination,
        replace: Boolean,
    )

    /**
     * Opens an App
     *
     * @param app The app to be opened
     *
     * @return The result of the action
     */
    fun openApp(app: App): App.OpenResult
}
