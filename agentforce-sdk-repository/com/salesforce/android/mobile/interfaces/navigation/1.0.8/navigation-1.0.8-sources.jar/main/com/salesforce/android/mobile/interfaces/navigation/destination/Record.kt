/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */

package com.salesforce.android.mobile.interfaces.navigation.destination

/**
 * A Record Destination
 *
 * @property id The record id
 * @property type The object type
 * @property original The original destination this was derived from, if any
 * @property pageReference A `standard__recordPage` page reference for this record. When not
 *   supplied it is derived from [id]/[type] (actionName `view`), matching the iOS SDK's `Record`
 *   initializer so hosts that forward navigation requests (e.g. the React Native bridge) emit a
 *   consistent payload cross-platform.
 */
data class Record
    @JvmOverloads
    constructor(
        val id: String,
        val type: String? = null,
        override val original: Destination? = null,
        override val pageReference: String? = buildRecordPageReference(id, type),
    ) : PageReference(pageReference, original)

/**
 * Builds a `standard__recordPage` page reference JSON string for a record, matching the shape the
 * iOS SDK's `Record` initializer produces: `{recordId, actionName: "view", objectApiName}`.
 * `objectApiName` is omitted when [type] is null or blank.
 *
 * Uses plain string building (not `org.json` or a serialization library) so it is safe to call
 * from a constructor default under any unit-test runner, including tests that do not use
 * Robolectric (where `org.json` is stubbed out by `isReturnDefaultValues = true`).
 */
private fun buildRecordPageReference(
    id: String,
    type: String?,
): String {
    val attributes =
        StringBuilder()
            .append("\"recordId\":\"").append(jsonEscape(id)).append("\",")
            .append("\"actionName\":\"view\"")
    if (!type.isNullOrBlank()) {
        attributes.append(",\"objectApiName\":\"").append(jsonEscape(type)).append("\"")
    }
    return "{\"type\":\"standard__recordPage\",\"attributes\":{$attributes}}"
}

/** Minimal JSON string escaping for values embedded in a page reference. */
private fun jsonEscape(value: String): String {
    val sb = StringBuilder(value.length)
    for (c in value) {
        when (c) {
            '\\' -> sb.append("\\\\")
            '"' -> sb.append("\\\"")
            '\n' -> sb.append("\\n")
            '\r' -> sb.append("\\r")
            '\t' -> sb.append("\\t")
            else -> sb.append(c)
        }
    }
    return sb.toString()
}
