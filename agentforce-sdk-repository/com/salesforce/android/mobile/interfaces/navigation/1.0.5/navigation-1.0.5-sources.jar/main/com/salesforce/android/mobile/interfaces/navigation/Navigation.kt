/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */
package com.salesforce.android.mobile.interfaces.navigation

import com.salesforce.android.mobile.interfaces.navigation.destination.App
import com.salesforce.android.mobile.interfaces.navigation.destination.Destination

interface Navigation {
    /**
     * Goes to a destination
     *
     * @param destination The destination
     */
    fun goto(destination: Destination)

    /**
     * Goes to a destination
     *
     * @param destination The destination
     * @param replace true if the host app needs to replace the existing page with this,
     *                false otherwise
     */
    fun goto(
        destination: Destination,
        replace: Boolean,
    )

    /**
     * Goes to a destination in the specified target pane.
     *
     * The default implementation degrades to [goto(destination, replace)], so existing
     * implementations that predate [NavigationTarget] continue to work without changes.
     *
     * @param destination The destination
     * @param target Where the destination should be presented ([NavigationTarget])
     * @param replace true if the host app should replace the existing page rather than adding to
     *                the back stack, false otherwise
     */
    fun goto(
        destination: Destination,
        target: NavigationTarget,
        replace: Boolean,
    )

    /**
     * Opens an App
     *
     * @param app The app to be opened
     *
     * @return The result of the action
     */
    fun openApp(app: App): App.OpenResult
}
