/*
 * Copyright (c) 2026 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */
package com.salesforce.android.mobile.interfaces.navigation

/**
 * Specifies where a navigation destination should be presented.
 *
 * The host app maps each target to an appropriate container for the current form factor.
 * On phone-sized screens, [DETAIL] degrades to [MAIN].
 *
 * UEM JSON values: "main", "detail", "modal", "sheet"
 */
enum class NavigationTarget {
    /** Primary pane — full-screen on phone, left/main pane on tablet. Default behavior. */
    MAIN,

    /** Secondary pane on tablet (e.g. right/detail pane). Degrades to [MAIN] on phone. */
    DETAIL,

    /** Modal overlay on all form factors. */
    MODAL,

    /** Sheet — ModalBottomSheet on Android, .sheet() on iOS. */
    SHEET,
}
