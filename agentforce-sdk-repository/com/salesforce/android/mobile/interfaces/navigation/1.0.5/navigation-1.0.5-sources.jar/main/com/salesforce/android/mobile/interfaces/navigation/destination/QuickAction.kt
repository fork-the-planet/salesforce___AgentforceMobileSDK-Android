/*
 * Copyright (c) 2025 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */
package com.salesforce.android.mobile.interfaces.navigation.destination

/**
 * QuickAction represents the Action bar event on the Mobile
 *
 * @property actionName The action name of the QuickAction
 * @property target  Context for the quick action if needed.
 * Each quick action can handle this differently
 * - A feed post will be made on this record's feed
 * - A new task will be added to a specific record
 * @property original @see [Destination]
 */
data class QuickAction
    @JvmOverloads
    constructor(
        val actionName: String,
        val target: Record? = null,
        override val original: Destination? = null,
    ) : Destination
