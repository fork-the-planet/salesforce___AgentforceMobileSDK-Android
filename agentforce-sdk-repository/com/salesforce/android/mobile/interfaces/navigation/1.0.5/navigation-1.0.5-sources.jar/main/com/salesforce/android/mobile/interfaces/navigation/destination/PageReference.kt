/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */

package com.salesforce.android.mobile.interfaces.navigation.destination

import android.net.Uri
import android.util.Log
import org.json.JSONException
import org.json.JSONObject

/**
 * A PageReference destination
 *
 * @property pageReference
 * @property org
 * @property original
 */
open class PageReference
    @JvmOverloads
    constructor(
        open val pageReference: String?,
        override val original: Destination? = null,
    ) : Destination {
        companion object Factory {
            private const val PAGE_TYPE = "type"
            private const val PAGE_ATTRIBUTES = "attributes"
            private const val STANDARD_RECORD_PAGE = "standard__recordPage"
            private const val STANDARD_OBJECT_PAGE = "standard__objectPage"
            private const val STANDARD_WEB_PAGE = "standard__webPage"
            private const val OBJECT_API_NAME = "objectApiName"
            private const val RECORD_ID = "recordId"
            private const val URL = "url"
            private val TAG = PageReference::class.java.canonicalName

            @JvmStatic
            @JvmOverloads
            fun create(
                pageReference: String,
                original: Destination? = null,
            ): Destination? {
                var destination: Destination? = null

                try {
                    val pageRefJSON = JSONObject(pageReference)
                    val pageType = pageRefJSON.getString(PAGE_TYPE)

                    if (pageType.isNullOrBlank()) {
                        Log.e(TAG, "PageReference is missing PageType ")
                        return null
                    }

                    when (pageType) {
                        STANDARD_OBJECT_PAGE -> {
                            val attributes: JSONObject =
                                pageRefJSON.getJSONObject(
                                    PAGE_ATTRIBUTES,
                                )

                            val objectApiName =
                                attributes.getString(OBJECT_API_NAME)

                            if (!objectApiName.isNullOrBlank()) {
                                destination = ObjectHome(objectApiName, original, pageReference)
                            } else {
                                Log.e(TAG, "PageReference is missing objectApiName unable to create Object Destination ")
                                return null
                            }
                        }

                        STANDARD_RECORD_PAGE -> {
                            val attributes: JSONObject =
                                pageRefJSON.getJSONObject(
                                    PAGE_ATTRIBUTES,
                                )

                            val recordId = attributes.getString(RECORD_ID)
                            val objectApiName = attributes.optString(OBJECT_API_NAME)

                            if (!recordId.isNullOrBlank()) {
                                destination =
                                    Record(recordId, objectApiName, original, pageReference)
                            } else {
                                Log.e(TAG, "PageReference is missing recordId unable to create Record Destination ")
                                return null
                            }
                        }

                        STANDARD_WEB_PAGE -> {
                            val attributes: JSONObject =
                                pageRefJSON.getJSONObject(
                                    PAGE_ATTRIBUTES,
                                )

                            val url = attributes.getString(URL)

                            if (!url.isNullOrBlank()) {
                                destination = Link(Uri.parse(url), original, pageReference)
                            } else {
                                Log.e(TAG, "PageReference is missing url unable to create Link Destination ")
                                return null
                            }
                        }

                        else -> {
                            // create a PageReference Destination by default
                            destination = PageReference(pageReference, original)
                        }
                    }
                } catch (e: JSONException) {
                    Log.e(TAG, "Failed to parse PageReference ", e)
                    return null
                }

                return destination
            }
        }
    }
