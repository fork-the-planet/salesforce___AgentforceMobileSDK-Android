/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */

package com.salesforce.android.mobile.interfaces.navigation.destination

/**
 * A Record Destination
 *
 * @property id The record id
 * @property id The object type
 * @property org The org record belongs to
 */
data class Record
    @JvmOverloads
    constructor(
        val id: String,
        val type: String? = null,
        override val original: Destination? = null,
        override val pageReference: String? = null,
    ) : PageReference(pageReference, original)
