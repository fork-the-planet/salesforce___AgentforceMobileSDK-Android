/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */

package com.salesforce.android.mobile.interfaces.navigation.destination

/**
 * ObjectHome represents a Object page destination
 */
data class ObjectHome
    @JvmOverloads
    constructor(
        val type: String,
        override val original: Destination? = null,
        override val pageReference: String? = null,
    ) : PageReference(pageReference, original)
