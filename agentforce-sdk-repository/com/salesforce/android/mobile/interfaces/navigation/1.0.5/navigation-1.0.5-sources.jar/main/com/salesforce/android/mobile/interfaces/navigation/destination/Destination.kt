/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */
package com.salesforce.android.mobile.interfaces.navigation.destination

/**
 * The destination protocol represents anything that can be navigated to,
 * examples are: Salesforce Records, Links, Lightning pages, etc...
 */
interface Destination {
    /**
     * Used by a router when manipulating a destination
     * Will be passed along to PluginNavigation to allow
     * a plugin to parse additional data from a URL/Lightning
     * in order to display specific data
     *
     * ### Example
     * Display a specific comment on a feed item
     */
    val original: Destination?
}
