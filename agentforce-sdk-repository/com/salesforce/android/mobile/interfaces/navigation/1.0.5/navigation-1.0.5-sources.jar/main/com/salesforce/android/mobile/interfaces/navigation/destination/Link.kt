/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */

package com.salesforce.android.mobile.interfaces.navigation.destination

import android.net.Uri

/**
 * Link represent only Salesforce endpoints
 * Org information can be provided via the org property
 * or inferred from the url itself
 * @property uri The link uri
 * @property org The org link belong to
 */
data class Link
    @JvmOverloads
    constructor(
        val uri: Uri,
        override val original: Destination? = null,
        override val pageReference: String? = null,
    ) : PageReference(pageReference, original)
