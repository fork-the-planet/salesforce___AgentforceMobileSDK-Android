/*
 * Copyright (c) 2019 Salesforce.com.
 * All Rights Reserved.
 * Company Confidential.
 */

package com.salesforce.android.mobile.interfaces.navigation.destination

import android.net.Uri

/**
 * The Open App
 *
 * @property packageName The package name of the opening app
 * @property uri The play store url of the opening app.
 *
 * When the app referred by the package name isn't installed on the device,
 * if the uri is provided, the url would be used to open,
 * otherwise, the uri would be created in this format
 * https://play.google.com/store/apps/details?id=<packageName>
 */
data class App(
    val packageName: String,
    val uri: Uri?,
) {
    enum class OpenResult {
        NOTOPEN,
        OPEN,
        STORE,
    }
}
